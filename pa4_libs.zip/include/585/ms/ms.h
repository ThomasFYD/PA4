#pragma once
#ifndef _585_MS_MS_H_
#define _585_MS_MS_H_

// SYSTEM INCLUDES
#include <Eigen/Dense>
#include <functional>
#include <map>
#include <tuple>


// C++ PROJECT INCLUDES
#include <585/common/types.h>


namespace ivc
{

    using Point = Eigen::VectorXf;      // a single point
    using PointCloud = Eigen::MatrixXf; // each row is a point

    const float_t         kernel(const float_t distance);
    const Eigen::VectorXf kernel(const Eigen::VectorXf& distances);

    using GrayscalePreprocessFunction = std::function<const ivc::PointCloud(const ivc::GrayscaleByteImg& img)>;
    using ColorPreprocessFunction = std::function<const ivc::PointCloud(const ivc::ColorByteImg& img)>;

    using GrayscaleLabelFunction = std::function<const uint8_t(const std::map<std::tuple<size_t, size_t>,
                                                                              ivc::Point>& pixel_to_center,
                                                               const ivc::PointCloud& unique_centers)>;
    using ColorLabelFunction = std::function<const ivc::Vec3b(const std::map<std::tuple<size_t, size_t>,
                                                                             ivc::Point>& pixel_to_center,
                                                              const ivc::PointCloud& unique_centers)>;

}


#endif // end of _585_MS_MS_H_

